#version 1.0;

argument vec4 a_position;
argument vec4 a_texCoord;
argument vec4 a_normal;

uniform mat4 u_modelViewProjectionMatrix;
uniform mat4 u_modelViewMatrix;
uniform vec4 u_time;
uniform vec4 u_upVector;
uniform vec4 u_lightParams;

varying vec4 v_texCoord0;
varying vec4 v_L2dir;
varying vec4 v_normalSpaceTransformX;
varying vec4 v_normalSpaceTransformY;
varying vec4 v_normalSpaceTransformZ;

m44 vt0.xyzw, a_position.xyzw, u_modelViewProjectionMatrix
mov op.xyzw, vt0.xyzw

mov vt1.y, u_time.xxxx
sin vt1.x, vt1.yyyy
add vt2.x, vt0.xxxx, vt1.xxxx

mov vt1.w, u_time.xxxx
cos vt1.z, vt1.wwww
add vt2.y, vt0.yyyy, vt1.zzzz

mul vt2.xy, vt2.xyxx, u_lightParams.xxxx

sub vt3.x, u_lightParams.zzzz, vt2.xxxx
sub vt3.y, u_lightParams.wwww, vt2.yyyy
mov vt3.z, u_lightParams.yyyy
nrm vt2.xyz, vt3.xyzx

nrm vt4.xyz, a_normal.xyzx
crs vt5.xyz, vt4.xyzx, u_upVector.xyzx
crs vt6.xyz, vt5.xyzx, vt4.xyzx

mov v0, u_lightParams
mov v0.xyz, vt2.xyzx

mov v1, u_lightParams
mov v1.xyz, vt6.xyzx

mov v2, u_lightParams
mov v2.xyz, vt5.xyzx

mov v3, u_lightParams
mov v3.xyz, vt4.xyzx

mov v4, u_lightParams
mov v4.xy, a_texCoord.xyxx