#version 1.0;

argument vec4 a_position;
argument vec4 a_color;
argument vec4 a_texCoord;
uniform mat4 u_modelViewProjectionMatrix;
uniform vec4 u_materialAmbient;

varying vec4 v_color;
varying vec2 v_texCoord;
varying vec4 v_pixelpos;

m44 vt0.xyzw, a_position.xyzw, u_modelViewProjectionMatrix
mov op.xyzw, vt0.xyzw

mul v0, a_color, u_materialAmbient
mov v2, a_texCoord
mov v1, vt0
