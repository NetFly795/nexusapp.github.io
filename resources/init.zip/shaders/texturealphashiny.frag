#version 1.0;

varying vec4 v_color;
varying vec2 v_texCoord;
varying vec4 v_pixelpos;

sampler2D u_texture;
uniform vec4 u_time;
uniform vec4 u_shinyConst;

// Sample texture (only alpha is used)
tex ft1, v2, fs0 <2d, wrap, linear>

// Load constants from u_shinyConst into temps (avoids two-constant-source violations)
// u_shinyConst: x=3.0, y=1.0, z=0.5, w=0.0
mov ft3.x, u_shinyConst.x
mov ft3.y, u_shinyConst.y
mov ft3.z, u_shinyConst.z

// --- Wave 1: clamp(0.5 + sin((v1.x + 1.0) * 3.0 + time * 3.0), 0, 1) ---
add ft0.x, v1.x, ft3.y
mul ft0.x, ft0.x, ft3.x
mul ft0.y, ft3.x, u_time.x
add ft0.z, ft0.x, ft0.y
sin ft0.w, ft0.z
add ft0.w, ft0.w, ft3.z
max ft0.w, ft0.w, u_time.y
min ft0.w, ft0.w, ft3.y

// --- Wave 2 gate: step(0, sin(v1.x + time)) ---
add ft0.x, v1.x, u_time.x
sin ft0.y, ft0.x
sge ft0.z, ft0.y, u_time.y

// --- Combined intensity ---
mul ft0.w, ft0.w, ft0.z

// --- Composite: rgb = tex.a + intensity * 0.5 * tex.a, a = tex.a ---
mul ft0.x, ft0.w, ft3.z
mul ft0.x, ft0.x, ft1.w
add ft2.xyz, ft1.w, ft0.x
mov ft2.w, ft1.w
mul oc, v0, ft2
