#version 1.0;

varying vec4 v_color;
varying vec2 v_texCoord;
varying vec4 v_pixelpos;

sampler2D u_texture;
uniform vec4 u_time;
uniform vec4 Settings;
uniform vec4 u_shinyConst;

// --- phase = texcoord.x + time ---
add ft0.y, v2.x, u_time.x

// --- period = Settings.z + Settings.w ---
mov ft0.z, Settings.z
add ft0.z, ft0.z, Settings.w

// --- mod(phase, period) = frac(phase/period) * period ---
div ft0.w, ft0.y, ft0.z
frc ft0.w, ft0.w
mul ft0.y, ft0.w, ft0.z

// --- clamp(mod - Settings.z, 0, Settings.w) ---
sub ft0.z, ft0.y, Settings.z
max ft0.z, ft0.z, u_time.y
min ft0.z, ft0.z, Settings.w

// --- normalized = clamped / Settings.w ---
div ft1.x, ft0.z, Settings.w

// --- sin(normalized * u_shinyConst.x) then positive half only ---
mul ft1.z, ft1.x, u_shinyConst.x
sin ft1.w, ft1.z
max ft1.w, ft1.w, u_time.y

// --- intensity = pow(max(Settings.x * sin, 0), Settings.y) ---
mul ft0.x, ft1.w, Settings.x
max ft0.x, ft0.x, u_time.y
pow ft0.y, ft0.x, Settings.y

// --- Sample texture, mask intensity by alpha ---
tex ft1, v2, fs0 <2d, repeat, linear, mipdisable>
mul ft0.z, ft0.y, ft1.w

// --- Output: rgb = shine * v_color, a = texture alpha ---
mov ft2.xyz, ft0.z
mov ft2.w, ft1.w
mul oc, v0, ft2
