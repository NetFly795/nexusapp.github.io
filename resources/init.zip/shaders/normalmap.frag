#version 1.0;

varying vec4 v_texCoord0;
varying vec4 v_L2dir;
varying vec4 v_normalSpaceTransformX;
varying vec4 v_normalSpaceTransformY;
varying vec4 v_normalSpaceTransformZ;

sampler2D u_texture;
sampler2D u_texture1;

uniform vec4 u_constants;
uniform vec4 u_materialAmbient;
uniform vec4 u_materialDiffuse;
uniform vec4 u_materialSpecular;
uniform vec4 u_materialShininess;
uniform vec4 u_color4;

// normalMap = texture2D(u_texture1, v_texCoord0)
tex ft0, v4, fs1 <2d, wrap, linear>

// remapped = normalMap.rgb - 0.5
sub ft1.xyz, ft0.xyzx, u_constants.xxxx

// world-space normal = mat3(X,Y,Z) * remapped  =  X*r.x + Y*r.y + Z*r.z
mul ft2.xyz, v1.xyzx, ft1.xxxx
mul ft3.xyz, v2.xyzx, ft1.yyyy
add ft2.xyz, ft2.xyzx, ft3.xyzx
mul ft3.xyz, v3.xyzx, ft1.zzzz
add ft2.xyz, ft2.xyzx, ft3.xyzx
nrm ft1.xyz, ft2.xyzx

// diffuse = clamp(dot(L, N), 0, 1)
dp3 ft2.x, v0.xyzx, ft1.xyzx
max ft2.x, ft2.xxxx, u_constants.zzzz
min ft2.x, ft2.xxxx, u_constants.yyyy

// specular = pow(diffuse, u_materialShininess)
pow ft2.y, ft2.xxxx, u_materialShininess.xxxx

// gl_FragColor = texture2D(u_texture, v_texCoord0)
tex ft3, v4, fs0 <2d, wrap, linear>

// gl_FragColor.rgb = tex.rgb * (diffuse_color * diffuse + ambient_color).rgb
mul ft4.xyz, u_materialDiffuse.xyzx, ft2.xxxx
add ft4.xyz, ft4.xyzx, u_materialAmbient.xyzx
mul ft4.xyz, ft3.xyzx, ft4.xyzx

// + spec_color * specular * normalMap.a
mul ft5.xyz, u_materialSpecular.xyzx, ft2.yyyy
mul ft5.xyz, ft5.xyzx, ft0.wwww
add ft4.xyz, ft4.xyzx, ft5.xyzx

// fade: rgb *= ambient.a
mul ft4.xyz, ft4.xyzx, u_materialAmbient.wwww

// alpha = tex.a
mov ft4.w, ft3.wwww

// gl_FragColor = ft4 * u_color4
mul oc, ft4, u_color4